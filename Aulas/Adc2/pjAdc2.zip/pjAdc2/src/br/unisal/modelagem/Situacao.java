package br.unisal.modelagem;

public enum Situacao {
	ATIVO, INATIVO, EXCLUIDO, LIBERADO_COMPRA, LIBERADO_VENDA, RESERVADO, REPROVADO;
	
}
